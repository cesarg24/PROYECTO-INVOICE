package com.facturacion.facturacion.exception;

public class ClientsNotFoundException extends Exception{

    public ClientsNotFoundException(String msg){super(msg);}

}
