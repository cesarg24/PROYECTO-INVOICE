package com.facturacion.facturacion.exception;

public class ProductsAlreadyExistException extends Exception{

    public ProductsAlreadyExistException(String msg) {
        super (msg);
    }
}
