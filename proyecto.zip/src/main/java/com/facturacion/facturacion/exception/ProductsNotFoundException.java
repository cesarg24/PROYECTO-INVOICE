package com.facturacion.facturacion.exception;

public class ProductsNotFoundException extends Exception{

    public ProductsNotFoundException(String msg){
        super(msg);
    }
}
