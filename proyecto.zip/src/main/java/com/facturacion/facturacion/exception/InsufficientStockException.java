package com.facturacion.facturacion.exception;

public class InsufficientStockException extends  Exception{

    public InsufficientStockException(String msg) {
        super (msg);
    }
}
