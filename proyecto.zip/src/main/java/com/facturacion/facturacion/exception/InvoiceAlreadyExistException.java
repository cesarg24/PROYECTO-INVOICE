package com.facturacion.facturacion.exception;

public class InvoiceAlreadyExistException extends Exception{

    public InvoiceAlreadyExistException(String msg) {
        super (msg);
    }

}
