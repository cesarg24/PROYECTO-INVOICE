package com.facturacion.facturacion.exception;

public class ClientsAlreadyExistException extends Exception{

    public ClientsAlreadyExistException(String msg) {
        super (msg);
    }
}
