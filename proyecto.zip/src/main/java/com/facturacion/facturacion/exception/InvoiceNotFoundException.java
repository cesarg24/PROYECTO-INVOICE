package com.facturacion.facturacion.exception;

public class InvoiceNotFoundException extends Exception{
    public InvoiceNotFoundException(String msg){
        super(msg);
    }
}
