package com.facturacion.facturacion.exception;

public class InvoiceDetailsNotFoundException extends Exception{

    public InvoiceDetailsNotFoundException(String msg){
        super(msg);
    }

}
